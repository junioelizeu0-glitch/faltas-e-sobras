import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Loader2, Save, X, Pencil, Trash2, AlertTriangle, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { listAllEtapasCatalogo, upsertEtapaCatalogo, deleteEtapaCatalogo, deleteMultipleEtapasCatalogo } from "@/lib/chamados.functions";
import Pagination from "./Pagination";

const PAGE_SIZE = 30;

const CREATE_ETAPAS_SQL = `-- Executar no SQL Editor do Supabase para criar a tabela etapas_catalogo
CREATE TABLE IF NOT EXISTS public.etapas_catalogo (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  dias_uteis integer NOT NULL DEFAULT 1,
  aplica_faltas boolean NOT NULL DEFAULT false,
  aplica_sobras boolean NOT NULL DEFAULT false,
  aplica_recall boolean NOT NULL DEFAULT false,
  ativo boolean NOT NULL DEFAULT true,
  ordem integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.etapas_catalogo TO service_role;
ALTER TABLE public.etapas_catalogo ENABLE ROW LEVEL SECURITY;`;

type T = { id: string; nome: string; dias_uteis: number; aplica_faltas: boolean; aplica_sobras: boolean; aplica_recall?: boolean; ativo: boolean; ordem: number };

export default function CadastroEtapas() {
  const list = useServerFn(listAllEtapasCatalogo);
  const up = useServerFn(upsertEtapaCatalogo);
  const del = useServerFn(deleteEtapaCatalogo);
  const delMultiple = useServerFn(deleteMultipleEtapasCatalogo);
  const [rows, setRows] = useState<T[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [tableMissing, setTableMissing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deletingMultiple, setDeletingMultiple] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "ok" | "err"; msg: string } | null>(null);
  const [editing, setEditing] = useState<Partial<T> | null>(null);
  const [page, setPage] = useState(0);

  const load = async () => {
    setLoading(true);
    setSelectedIds(new Set());
    try {
      const res = await list() as any;
      let rawRows: T[] = [];
      if (res && typeof res === "object" && "rows" in res) {
        rawRows = res.rows || [];
        setTableMissing(!!res.tableMissing);
      } else if (Array.isArray(res)) {
        rawRows = res;
        setTableMissing(false);
      }
      const seen = new Set<string>();
      const unique: T[] = [];
      for (const item of rawRows) {
        const key = String(item.nome || "").replace(/\s*\[recall\]/i, "").trim().toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          unique.push(item);
        }
      }
      setRows(unique);
    } catch (e: any) {
      if (e?.message?.includes("etapas_catalogo") || e?.message?.includes("schema cache")) {
        setTableMissing(true);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const paginated = useMemo(() => rows.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE), [rows, page]);
  useEffect(() => { setPage(0); }, [rows.length]);

  const isAllPageSelected = useMemo(() => {
    if (paginated.length === 0) return false;
    return paginated.every((r) => selectedIds.has(r.id));
  }, [paginated, selectedIds]);

  const toggleSelectAll = () => {
    const next = new Set(selectedIds);
    if (isAllPageSelected) {
      paginated.forEach((r) => next.delete(r.id));
    } else {
      paginated.forEach((r) => next.add(r.id));
    }
    setSelectedIds(next);
  };

  const toggleSelectRow = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const removeSelected = async () => {
    const count = selectedIds.size;
    if (count === 0) return;
    if (!confirm(`Tem certeza que deseja excluir as ${count} etapas selecionadas?`)) return;
    setDeletingMultiple(true);
    try {
      await delMultiple({ data: { ids: Array.from(selectedIds) } });
      toast.success(`${count} ${count === 1 ? "etapa excluída" : "etapas excluídas"} com sucesso!`);
      setSelectedIds(new Set());
      await load();
    } catch (e: any) {
      toast.error(e?.message || "Erro ao excluir etapas selecionadas.");
    } finally {
      setDeletingMultiple(false);
    }
  };

  const copySql = () => {
    navigator.clipboard.writeText(CREATE_ETAPAS_SQL);
    setCopied(true);
    toast.success("Script SQL copiado para a área de transferência!");
    setTimeout(() => setCopied(false), 2000);
  };

  const save = async () => {
    setFeedback(null);
    if (!editing?.nome?.trim()) {
      const msg = "O nome da etapa é obrigatório.";
      setFeedback({ type: "err", msg });
      toast.error(msg);
      return;
    }
    setSaving(true);
    try {
      await up({ data: {
        id: editing.id, nome: editing.nome.trim(), dias_uteis: Number(editing.dias_uteis) || 1,
        aplica_faltas: !!editing.aplica_faltas, aplica_sobras: !!editing.aplica_sobras,
        aplica_recall: !!editing.aplica_recall,
        ativo: editing.ativo !== false, ordem: Number(editing.ordem) || 0,
      }});
      const msg = editing.id ? "Etapa atualizada com sucesso!" : "Etapa criada com sucesso!";
      setFeedback({ type: "ok", msg });
      toast.success(msg);
      await load();
      setTimeout(() => { setEditing(null); }, 700);
    } catch (e: any) {
      const msg = e?.message || "Erro ao salvar etapa no banco de dados";
      setFeedback({ type: "err", msg });
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Remover etapa do catálogo?")) return;
    try {
      await del({ data: { id } });
      toast.success("Etapa removida com sucesso!");
      await load();
    } catch (e: any) {
      toast.error(e?.message || "Erro ao remover etapa");
    }
  };

  return (
    <div className="flex-1 min-h-screen bg-[#F4F6F5] p-4 md:p-6 space-y-6 text-slate-800 font-sans">
      <div className="w-full bg-white rounded-2xl border border-slate-200/70 shadow-[0_2px_10px_rgba(0,0,0,0.03)] p-6 space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Cadastro de Etapas do Fluxo</h1>
            <p className="text-xs text-slate-500 mt-1">Gerencie as etapas disponíveis para a aba Etapas dos chamados.</p>
          </div>
          <div className="flex items-center gap-2">
            {selectedIds.size > 0 && (
              <button
                disabled={deletingMultiple}
                onClick={removeSelected}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl cursor-pointer shadow-xs transition-colors disabled:opacity-50"
              >
                {deletingMultiple ? <Loader2 className="w-4 h-4 animate-spin"/> : <Trash2 className="w-4 h-4"/>}
                <span>Excluir Selecionadas ({selectedIds.size})</span>
              </button>
            )}
            <button
              onClick={() => setEditing({ ativo: true, aplica_faltas: true, aplica_sobras: false, aplica_recall: false })}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl cursor-pointer shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4"/>
              <span>Nova Etapa</span>
            </button>
          </div>
        </header>

        {tableMissing && (
          <div className="p-4 md:p-5 rounded-2xl bg-amber-50/90 border border-amber-200 text-amber-900 text-xs space-y-3 shadow-xs">
            <div className="flex items-start gap-2.5 font-bold text-amber-900 text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <span>Tabela <code className="bg-amber-100/90 text-amber-950 px-1.5 py-0.5 rounded-md font-mono border border-amber-300/60">public.etapas_catalogo</code> não encontrada no Supabase</span>
                <p className="text-xs font-normal text-amber-800 mt-1">
                  A tabela necessária para armazenar o cadastro de etapas ainda não existe no seu projeto do Supabase.
                  Para ativá-la, copie o comando SQL abaixo e execute no <strong>SQL Editor</strong> do painel Supabase:
                </p>
              </div>
            </div>
            <div className="relative mt-2">
              <pre className="bg-slate-900 text-slate-100 p-4 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto border border-slate-800">
{CREATE_ETAPAS_SQL}
              </pre>
              <button
                onClick={copySql}
                className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors cursor-pointer shadow-xs"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "Copiado!" : "Copiar SQL"}</span>
              </button>
            </div>
          </div>
        )}

        <div className="bg-white border border-slate-200/80 rounded-xl shadow-xs overflow-hidden">
          {loading ? (
            <div className="p-12 text-center text-slate-500">
              <Loader2 className="inline w-6 h-6 animate-spin mr-2 text-emerald-600"/>
              <span>Carregando etapas do fluxo...</span>
            </div>
          ) : (
            <table className="min-w-full text-xs text-left border-collapse">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[11px] border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={isAllPageSelected}
                      onChange={toggleSelectAll}
                      className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      title="Selecionar todos da página"
                    />
                  </th>
                  <th className="px-4 py-3">Ordem</th>
                  <th className="px-4 py-3">Nome da Etapa</th>
                  <th className="px-4 py-3">SLA</th>
                  <th className="px-4 py-3">Faltas</th>
                  <th className="px-4 py-3">Sobras</th>
                  <th className="px-4 py-3">Recall</th>
                  <th className="px-4 py-3">Ativo</th>
                  <th className="px-4 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {paginated.map((r) => {
                  const isSelected = selectedIds.has(r.id);
                  return (
                    <tr key={r.id} className={`transition-colors ${isSelected ? "bg-emerald-50/50" : "hover:bg-slate-50/80"}`}>
                      <td className="px-4 py-3 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectRow(r.id)}
                          className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-slate-500">{r.ordem}</td>
                      <td className="px-4 py-3 font-bold text-slate-900">{r.nome}</td>
                      <td className="px-4 py-3 text-slate-700 font-medium">{r.dias_uteis} dias úteis</td>
                      <td className="px-4 py-3">{r.aplica_faltas ? <span className="text-emerald-600 font-bold">✓</span> : <span className="text-slate-300">—</span>}</td>
                      <td className="px-4 py-3">{r.aplica_sobras ? <span className="text-emerald-600 font-bold">✓</span> : <span className="text-slate-300">—</span>}</td>
                      <td className="px-4 py-3">{r.aplica_recall ? <span className="text-emerald-600 font-bold">✓</span> : <span className="text-slate-300">—</span>}</td>
                      <td className="px-4 py-3">{r.ativo ? <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">Sim</span> : <span className="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500">Não</span>}</td>
                      <td className="px-4 py-3 text-right space-x-1">
                        <button onClick={() => setEditing(r)} title="Editar" className="inline-flex items-center p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer">
                          <Pencil className="w-3.5 h-3.5"/>
                        </button>
                        <button onClick={() => remove(r.id)} title="Excluir" className="inline-flex items-center p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer">
                          <Trash2 className="w-3.5 h-3.5"/>
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {rows.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                      Nenhuma etapa cadastrada no catálogo.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
        <Pagination page={page} totalPages={totalPages} onChange={setPage} totalItems={rows.length} pageSize={PAGE_SIZE} />
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="font-bold text-slate-900">{editing.id ? "Editar" : "Nova"} Etapa do Fluxo</h3>
              <button onClick={() => setEditing(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5"/>
              </button>
            </div>
            <div className="p-6 space-y-4 text-xs">
              {feedback && (
                <div className={`p-3 rounded-xl border flex items-center justify-between text-xs font-semibold ${feedback.type === "ok" ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-rose-50 text-rose-800 border-rose-200"}`}>
                  <span>{feedback.msg}</span>
                  <button onClick={() => setFeedback(null)} className="text-xs opacity-60 hover:opacity-100">✕</button>
                </div>
              )}
              <label className="block">
                <span className="font-semibold text-slate-600">Nome da Etapa *</span>
                <input autoFocus value={editing.nome || ""} onChange={(e) => setEditing({ ...editing, nome: e.target.value })} placeholder="Ex.: Conferência Física de Produtos" className="mt-1.5 w-full text-sm rounded-xl border border-slate-200 px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white font-medium"/>
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="block">
                  <span className="font-semibold text-slate-600">SLA (dias úteis)</span>
                  <input type="number" min={0} value={editing.dias_uteis ?? ""} onChange={(e) => setEditing({ ...editing, dias_uteis: e.target.value === "" ? undefined : Number(e.target.value) })} className="mt-1.5 w-full text-sm rounded-xl border border-slate-200 px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white font-medium"/>
                </label>
                <label className="block">
                  <span className="font-semibold text-slate-600">Ordem</span>
                  <input type="number" value={editing.ordem ?? ""} onChange={(e) => setEditing({ ...editing, ordem: e.target.value === "" ? undefined : Number(e.target.value) })} className="mt-1.5 w-full text-sm rounded-xl border border-slate-200 px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-white font-medium"/>
                </label>
              </div>
              <div className="flex gap-4 text-xs pt-2 flex-wrap">
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input type="checkbox" checked={!!editing.aplica_faltas} onChange={(e) => setEditing({ ...editing, aplica_faltas: e.target.checked })} className="rounded text-emerald-600 focus:ring-emerald-500"/>
                  Faltas
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input type="checkbox" checked={!!editing.aplica_sobras} onChange={(e) => setEditing({ ...editing, aplica_sobras: e.target.checked })} className="rounded text-emerald-600 focus:ring-emerald-500"/>
                  Sobras
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input type="checkbox" checked={!!editing.aplica_recall} onChange={(e) => setEditing({ ...editing, aplica_recall: e.target.checked })} className="rounded text-emerald-600 focus:ring-emerald-500"/>
                  Recall
                </label>
                <label className="inline-flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input type="checkbox" checked={editing.ativo !== false} onChange={(e) => setEditing({ ...editing, ativo: e.target.checked })} className="rounded text-emerald-600 focus:ring-emerald-500"/>
                  Ativo
                </label>
              </div>
            </div>
            <div className="flex justify-end gap-3 px-6 py-4 border-t border-slate-200 bg-slate-50">
              <button disabled={saving} onClick={() => setEditing(null)} className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer disabled:opacity-50">
                Cancelar
              </button>
              <button disabled={saving} onClick={save} className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl transition-colors cursor-pointer shadow-xs disabled:opacity-50">
                {saving ? <Loader2 className="w-4 h-4 animate-spin"/> : <Save className="w-4 h-4"/>}
                <span>{saving ? "Salvando..." : "Salvar"}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
