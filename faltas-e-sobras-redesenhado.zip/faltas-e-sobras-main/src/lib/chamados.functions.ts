import { createServerFn } from "@tanstack/react-start";
import { getParceiroByLoja } from "./lojas-parceiros.data";

async function getSupabase() {
  const { getServerSupabase } = await import("@/integrations/supabase/server-client");
  return getServerSupabase();
}

// Cria/atualiza o conferente com o CD do chamado (silencioso em caso de erro).
async function upsertConferenteCD(supabase: any, nome: string | null, cd: string | null) {
  const n = (nome || "").trim();
  if (!n) return;
  try {
    const { data: existing } = await supabase.from("conferentes").select("id, cd").ilike("nome", n).maybeSingle();
    if (existing) {
      if (cd && existing.cd !== cd) {
        await supabase.from("conferentes").update({ cd }).eq("id", existing.id);
      }
    } else {
      await supabase.from("conferentes").insert({ nome: n, cd: cd || null });
    }
  } catch { /* silencioso */ }
}
async function upsertTransportadora(supabase: any, nome: string | null) {
  const n = (nome || "").trim();
  if (!n) return;
  try {
    const { data: existing } = await supabase.from("transportadoras").select("id").ilike("nome", n).maybeSingle();
    if (!existing) await supabase.from("transportadoras").insert({ nome: n });
  } catch { /* silencioso */ }
}


// ===== Feriados / dias úteis =====
const FERIADOS_FIXOS = new Set([
  "01-01", "04-21", "05-01", "09-07", "10-12", "11-02", "11-15", "12-25",
]);
function isDiaUtil(d: Date) {
  const dow = d.getDay();
  if (dow === 0 || dow === 6) return false;
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return !FERIADOS_FIXOS.has(`${mm}-${dd}`);
}
function diasUteisEntre(ini: Date, fim: Date): number {
  if (fim < ini) return 0;
  let count = 0;
  const cur = new Date(ini.getFullYear(), ini.getMonth(), ini.getDate());
  const end = new Date(fim.getFullYear(), fim.getMonth(), fim.getDate());
  while (cur <= end) {
    if (isDiaUtil(cur)) count++;
    cur.setDate(cur.getDate() + 1);
  }
  return Math.max(0, count - 1);
}
function parseISO(s?: string | null): Date | null {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (!m) return null;
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

// ===== Tipos =====
export type TarefaCatalogo = {
  id: string;
  nome: string;
  dias_uteis: number;
  aplica_faltas: boolean;
  aplica_sobras: boolean;
  aplica_recall?: boolean;
  ativo: boolean;
  ordem: number;
};

export type ReferenciaInput = {
  referencia?: string;
  cor?: string;
  tamanho?: string;
  fornecedor?: string;
  descricao?: string;
  quantidade?: number | string;
};

export type EtapaInput = {
  tarefa_id?: string | null;
  nome_tarefa: string;
  dias_uteis_previsto?: number | null;
  dt_inicio?: string | null;
  dt_fim?: string | null;
  ordem?: number;
};

function normalizeTarefaRow(r: any): TarefaCatalogo {
  const rawNome = String(r.nome || "").trim();
  const hasRecallTag = /\[recall\]/i.test(rawNome);
  const cleanNome = rawNome.replace(/\s*\[recall\]/i, "").trim();

  let recallVal = r.aplica_recall;
  if (recallVal === undefined || recallVal === null) {
    recallVal = hasRecallTag ? true : false;
  } else {
    recallVal = !!recallVal;
  }

  return {
    id: r.id,
    nome: cleanNome,
    dias_uteis: Number(r.dias_uteis) || 1,
    aplica_faltas: r.aplica_faltas !== false,
    aplica_sobras: !!r.aplica_sobras,
    aplica_recall: recallVal,
    ativo: r.ativo !== false,
    ordem: Number(r.ordem) || 0,
  };
}

// ===== Tarefas catálogo =====
const DEFAULT_SITUACOES = [
  { nome: "Aguardando monitoramento", dias_uteis: 2, aplica_faltas: true, aplica_sobras: true, aplica_recall: false, ordem: 1 },
  { nome: "Recall", dias_uteis: 1, aplica_faltas: false, aplica_sobras: false, aplica_recall: true, ordem: 2 },
  { nome: "Aguardando NF Espelho", dias_uteis: 3, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 4 },
  { nome: "Validação NF Espelho", dias_uteis: 4, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 5 },
  { nome: "Aguardando NFD", dias_uteis: 3, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 6 },
  { nome: "Emitir NFD", dias_uteis: 2, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 7 },
  { nome: "Importação NF", dias_uteis: 2, aplica_faltas: true, aplica_sobras: false, aplica_recall: true, ordem: 8 },
  { nome: "Dados Bancários", dias_uteis: 2, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 9 },
  { nome: "Enviada Solicitação Provisionamento", dias_uteis: 2, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 10 },
  { nome: "Pendente Provisionamento Financeiro", dias_uteis: 5, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 11 },
  { nome: "Pagamento Provisionado", dias_uteis: 5, aplica_faltas: true, aplica_sobras: false, aplica_recall: false, ordem: 12 },
  { nome: "Chamado Aprovado", dias_uteis: 1, aplica_faltas: true, aplica_sobras: true, aplica_recall: true, ordem: 13 },
  { nome: "Chamado Recusado", dias_uteis: 1, aplica_faltas: true, aplica_sobras: true, aplica_recall: true, ordem: 14 },
  { nome: "Sem retorno (Finalizado)", dias_uteis: 1, aplica_faltas: true, aplica_sobras: true, aplica_recall: true, ordem: 15 },
  { nome: "Finalizar Chamado", dias_uteis: 1, aplica_faltas: true, aplica_sobras: true, aplica_recall: true, ordem: 16 },
  { nome: "Finalizado", dias_uteis: 1, aplica_faltas: true, aplica_sobras: true, aplica_recall: true, ordem: 17 },
];

function deduplicateTarefasList<T extends TarefaCatalogo>(list: T[]): T[] {
  const seen = new Set<string>();
  const res: T[] = [];
  for (const item of list) {
    const key = String(item.nome || "").replace(/\s*\[recall\]/i, "").trim().toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      res.push(item);
    }
  }
  return res;
}

async function ensureDefaultSituacoes(supabase: any) {
  try {
    // 1. Limpa registros duplicados da tabela tarefas_catalogo no banco
    const { data: allRows } = await supabase.from("tarefas_catalogo").select("*").order("ordem", { ascending: true });
    
    if (allRows && allRows.length > 0) {
      const grouped = new Map<string, any[]>();
      for (const row of allRows) {
        const cleanNome = String(row.nome || "").replace(/\s*\[recall\]/i, "").trim();
        const key = cleanNome.toLowerCase();
        if (!key) continue;
        if (!grouped.has(key)) {
          grouped.set(key, []);
        }
        grouped.get(key)!.push(row);
      }

      const idsToDelete: string[] = [];
      for (const [key, group] of grouped.entries()) {
        const cleanNome = group[0].nome.replace(/\s*\[recall\]/i, "").trim();
        if (group.length > 1) {
          // Mantém a linha principal (preferencialmente nome exato sem sufixo ou menor ID/ordem)
          const primary = group.find((r: any) => String(r.nome || "").trim().toLowerCase() === key) || group[0];
          
          const mergedFaltas = group.some((r: any) => r.aplica_faltas !== false);
          const mergedSobras = group.some((r: any) => !!r.aplica_sobras);
          const mergedRecall = group.some((r: any) => !!r.aplica_recall || /\[recall\]/i.test(r.nome));
          const mergedAtivo = group.some((r: any) => r.ativo !== false);
          
          await supabase.from("tarefas_catalogo").update({
            nome: cleanNome,
            aplica_faltas: mergedFaltas,
            aplica_sobras: mergedSobras,
            aplica_recall: mergedRecall,
            ativo: mergedAtivo
          }).eq("id", primary.id);

          for (const row of group) {
            if (row.id !== primary.id) {
              idsToDelete.push(row.id);
              try {
                await supabase.from("chamados_etapas").update({ tarefa_id: primary.id }).eq("tarefa_id", row.id);
              } catch (e) {}
              try {
                await supabase.from("chamados_recall_etapas").update({ tarefa_id: primary.id }).eq("tarefa_id", row.id);
              } catch (e) {}
            }
          }
        } else {
          // Linha única - garante nome limpo sem tag [recall] legada no campo nome
          const row = group[0];
          if (row.nome !== cleanNome) {
            await supabase.from("tarefas_catalogo").update({ nome: cleanNome }).eq("id", row.id);
          }
        }
      }

      if (idsToDelete.length > 0) {
        for (const id of idsToDelete) {
          await supabase.from("tarefas_catalogo").delete().eq("id", id);
        }
      }
    }

    // 2. Insere situações padrão faltantes
    const { data: existing } = await supabase.from("tarefas_catalogo").select("nome");
    const existingNames = new Set(
      (existing ?? []).map((x: any) => String(x.nome || "").replace(/\s*\[recall\]/i, "").trim().toLowerCase())
    );
    const missing = DEFAULT_SITUACOES.filter((s) => !existingNames.has(s.nome.trim().toLowerCase()));
    if (missing.length > 0) {
      const rows = missing.map((s) => ({
        nome: s.nome,
        dias_uteis: s.dias_uteis,
        aplica_faltas: s.aplica_faltas,
        aplica_sobras: s.aplica_sobras,
        aplica_recall: s.aplica_recall,
        ativo: true,
        ordem: s.ordem,
      }));
      await supabase.from("tarefas_catalogo").insert(rows);
    }

    // 3. Garante que Importação NF esteja habilitada para Recall
    await supabase.from("tarefas_catalogo").update({ aplica_recall: true }).ilike("nome", "%importa%nf%");

    // 4. Tenta adicionar a coluna glpi na tabela chamados_recall caso o RPC esteja disponível
    try {
      await supabase.rpc("aiiliana_run_sql", {
        sql: "ALTER TABLE public.chamados_recall ADD COLUMN IF NOT EXISTS glpi TEXT;"
      });
    } catch {}
  } catch (e) {
    /* silent fallback */
  }
}

export const listTarefas = createServerFn({ method: "GET" })
  .validator((data: { tipo?: "FALTAS" | "SOBRAS" | "RECALL" | "TODAS" } | undefined) => data ?? {})
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    await ensureDefaultSituacoes(supabase);
    let q = supabase.from("tarefas_catalogo").select("*").eq("ativo", true).order("ordem", { ascending: true });
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const normalized = (rows ?? []).map(normalizeTarefaRow);
    const tipo = data?.tipo;
    const filtered = normalized.filter((r) => {
      if (!tipo || tipo === "TODAS") return true;
      if (tipo === "FALTAS") return r.aplica_faltas;
      if (tipo === "SOBRAS") return r.aplica_sobras;
      if (tipo === "RECALL") return r.aplica_recall;
      return true;
    });
    return deduplicateTarefasList(filtered);
  });

export const listAllTarefas = createServerFn({ method: "GET" }).handler(async () => {
  const { requireUnlockedSession } = await import("@/lib/gate.server");
  await requireUnlockedSession();
  const supabase = await getSupabase();
  await ensureDefaultSituacoes(supabase);
  const { data, error } = await supabase.from("tarefas_catalogo").select("*").order("ordem", { ascending: true });
  if (error) throw new Error(error.message);
  return deduplicateTarefasList((data ?? []).map(normalizeTarefaRow));
});

export const upsertTarefa = createServerFn({ method: "POST" })
  .validator((data: {
    id?: string;
    nome: string;
    dias_uteis: number;
    aplica_faltas: boolean;
    aplica_sobras: boolean;
    aplica_recall?: boolean;
    ativo?: boolean;
    ordem?: number;
  }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    const baseNome = data.nome.replace(/\s*\[recall\]/i, "").trim();
    const isRecall = !!data.aplica_recall;

    const rowFull: any = {
      nome: baseNome,
      dias_uteis: Number(data.dias_uteis) || 1,
      aplica_faltas: !!data.aplica_faltas,
      aplica_sobras: !!data.aplica_sobras,
      aplica_recall: isRecall,
      ativo: data.ativo !== false,
      ordem: Number(data.ordem) || 0,
    };

    if (data.id) {
      let { error } = await supabase.from("tarefas_catalogo").update(rowFull).eq("id", data.id);
      if (error && (error.message?.includes("aplica_recall") || error.code === "PGRST204")) {
        const { aplica_recall, ...rowWithoutRecall } = rowFull;
        rowWithoutRecall.nome = isRecall ? `${baseNome} [recall]` : baseNome;
        const res = await supabase.from("tarefas_catalogo").update(rowWithoutRecall).eq("id", data.id);
        error = res.error;
      }
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }

    let { data: inserted, error } = await supabase.from("tarefas_catalogo").insert(rowFull).select().single();
    if (error && (error.message?.includes("aplica_recall") || error.code === "PGRST204")) {
      const { aplica_recall, ...rowWithoutRecall } = rowFull;
      rowWithoutRecall.nome = isRecall ? `${baseNome} [recall]` : baseNome;
      const res = await supabase.from("tarefas_catalogo").insert(rowWithoutRecall).select().single();
      inserted = res.data;
      error = res.error;
    }
    if (error) throw new Error(error.message);
    return { ok: true, id: inserted?.id };
  });

export const deleteTarefa = createServerFn({ method: "POST" })
  .validator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    const { error } = await supabase.from("tarefas_catalogo").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMultipleTarefas = createServerFn({ method: "POST" })
  .validator((data: { ids: string[] }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    if (!data.ids || data.ids.length === 0) return { ok: true, count: 0 };
    const supabase = await getSupabase();
    const { error, count } = await supabase.from("tarefas_catalogo").delete().in("id", data.ids);
    if (error) throw new Error(error.message);
    return { ok: true, count };
  });

// ===== Etapas catálogo =====
export const listEtapasCatalogo = createServerFn({ method: "GET" })
  .validator((data: { tipo?: "FALTAS" | "SOBRAS" | "RECALL" | "TODAS" } | undefined) => data ?? {})
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    let q = supabase.from("etapas_catalogo").select("*").eq("ativo", true).order("ordem", { ascending: true });
    let { data: rows, error } = await q;
    if (error && (error.code === "PGRST205" || error.code === "42P01" || error.message?.includes("etapas_catalogo"))) {
      return [];
    }
    if (error) throw new Error(error.message);
    const normalized = (rows ?? []).map(normalizeTarefaRow);
    const tipo = data?.tipo;
    const filtered = normalized.filter((r) => {
      if (!tipo || tipo === "TODAS") return true;
      if (tipo === "FALTAS") return r.aplica_faltas;
      if (tipo === "SOBRAS") return r.aplica_sobras;
      if (tipo === "RECALL") return r.aplica_recall;
      return true;
    });
    return filtered;
  });

export const listAllEtapasCatalogo = createServerFn({ method: "GET" }).handler(async () => {
  const { requireUnlockedSession } = await import("@/lib/gate.server");
  await requireUnlockedSession();
  const supabase = await getSupabase();
  const { data, error } = await supabase.from("etapas_catalogo").select("*").order("ordem", { ascending: true });
  if (error && (error.code === "PGRST205" || error.code === "42P01" || error.message?.includes("etapas_catalogo") || error.message?.includes("schema cache"))) {
    return { rows: [], tableMissing: true };
  }
  if (error) throw new Error(error.message);
  const rows = (data ?? []).map(normalizeTarefaRow);
  return { rows, tableMissing: false };
});

export const upsertEtapaCatalogo = createServerFn({ method: "POST" })
  .validator((data: {
    id?: string;
    nome: string;
    dias_uteis: number;
    aplica_faltas: boolean;
    aplica_sobras: boolean;
    aplica_recall?: boolean;
    ativo?: boolean;
    ordem?: number;
  }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    const baseNome = data.nome.replace(/\s*\[recall\]/i, "").trim();
    const isRecall = !!data.aplica_recall;

    const rowFull: any = {
      nome: baseNome,
      dias_uteis: Number(data.dias_uteis) || 1,
      aplica_faltas: !!data.aplica_faltas,
      aplica_sobras: !!data.aplica_sobras,
      aplica_recall: isRecall,
      ativo: data.ativo !== false,
      ordem: Number(data.ordem) || 0,
    };

    const isMissingTable = (err: any) => err && (err.code === "PGRST205" || err.code === "42P01" || err.message?.includes("etapas_catalogo") || err.message?.includes("schema cache"));

    if (data.id) {
      let { error } = await supabase.from("etapas_catalogo").update(rowFull).eq("id", data.id);
      if (error && (error.message?.includes("aplica_recall") || error.code === "PGRST204")) {
        const { aplica_recall, ...rowWithoutRecall } = rowFull;
        const res = await supabase.from("etapas_catalogo").update(rowWithoutRecall).eq("id", data.id);
        error = res.error;
      }
      if (isMissingTable(error)) {
        throw new Error("A tabela 'public.etapas_catalogo' não foi encontrada no banco Supabase. Por favor, execute o script SQL de criação no Supabase SQL Editor.");
      }
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }

    let { data: inserted, error } = await supabase.from("etapas_catalogo").insert(rowFull).select().single();
    if (error && (error.message?.includes("aplica_recall") || error.code === "PGRST204")) {
      const { aplica_recall, ...rowWithoutRecall } = rowFull;
      const res = await supabase.from("etapas_catalogo").insert(rowWithoutRecall).select().single();
      inserted = res.data;
      error = res.error;
    }
    if (isMissingTable(error)) {
      throw new Error("A tabela 'public.etapas_catalogo' não foi encontrada no banco Supabase. Por favor, execute o script SQL de criação no Supabase SQL Editor.");
    }
    if (error) throw new Error(error.message);
    return { ok: true, id: inserted?.id };
  });

export const deleteEtapaCatalogo = createServerFn({ method: "POST" })
  .validator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();
    const { error } = await supabase.from("etapas_catalogo").delete().eq("id", data.id);
    if (error && (error.code === "PGRST205" || error.code === "42P01" || error.message?.includes("etapas_catalogo") || error.message?.includes("schema cache"))) {
      throw new Error("A tabela 'public.etapas_catalogo' não foi encontrada no banco Supabase. Por favor, execute o script SQL de criação no Supabase SQL Editor.");
    }
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMultipleEtapasCatalogo = createServerFn({ method: "POST" })
  .validator((data: { ids: string[] }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    if (!data.ids || data.ids.length === 0) return { ok: true, count: 0 };
    const supabase = await getSupabase();
    const { error, count } = await supabase.from("etapas_catalogo").delete().in("id", data.ids);
    if (error && (error.code === "PGRST205" || error.code === "42P01" || error.message?.includes("etapas_catalogo") || error.message?.includes("schema cache"))) {
      throw new Error("A tabela 'public.etapas_catalogo' não foi encontrada no banco Supabase. Por favor, execute o script SQL de criação no Supabase SQL Editor.");
    }
    if (error) throw new Error(error.message);
    return { ok: true, count };
  });
// ===== Chamado completo =====
export const createChamadoCompleto = createServerFn({ method: "POST" })
  .validator((data: {
    chamado: any; // mesmo formato do createChamado atual (NovoChamadoPayload sem aba)
    referencias: ReferenciaInput[];
    etapas: EtapaInput[];
    tabela?: "faltas" | "recall";
  }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();

    const tblMain = data.tabela === "recall" ? "chamados_recall" : "chamados_faltas";
    const tblRefs = data.tabela === "recall" ? "chamados_recall_referencias" : "chamados_referencias";
    const tblEtapas = data.tabela === "recall" ? "chamados_recall_etapas" : "chamados_etapas";

    const c = data.chamado;
    const nullIfEmpty = (v: any) => {
      if (v === undefined || v === null) return null;
      const s = String(v).trim();
      return s === "" ? null : s;
    };
    const numOrNull = (v: any) => {
      const s = nullIfEmpty(v);
      if (!s) return null;
      const n = Number(String(s).replace(",", "."));
      return isNaN(n) ? null : n;
    };
    const dateOrNull = (v: any) => {
      const s = nullIfEmpty(v);
      if (!s) return null;
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
      if (m) return `${m[1]}-${m[2]}-${m[3]}`;
      const d = new Date(s);
      if (isNaN(d.getTime())) return null;
      return d.toISOString().slice(0, 10);
    };

    const chamadoRow: any = {
      chamado: nullIfEmpty(c.Chamado),
      loja: nullIfEmpty(c.Loja),
      tipo: nullIfEmpty(c.Tipo),
      nf: nullIfEmpty(c.NF),
      dt_emissao: dateOrNull(c["Dt Emissão"]),
      valor: numOrNull(c[" Valor "]),
      cd: nullIfEmpty(c.CD),
      situacao: nullIfEmpty(c["Situação "]),
      dt_abertura: dateOrNull(c["Dt Abertura"]),
      dt_finalizacao: dateOrNull(c["Dt Finalização"]),
      dt_pagamento: dateOrNull(c["Dt Pagamento"]),
      sla_status: nullIfEmpty(c["SLA por chamado (60dias)"]),
      status_pagamento: nullIfEmpty(c["Status Pagamento"]),
      status_chamado: nullIfEmpty(c["Status Chamado"]),
      motivo: nullIfEmpty(c.Motivo),
      transportadora: nullIfEmpty(c.Transportadora),
      conferente: nullIfEmpty(c.conferente || c.Conferente),
      periodo: dateOrNull(c.Periodo),
      parceiro: nullIfEmpty(c.Parceiro || c.parceiro) || (c.Loja ? getParceiroByLoja(c.Loja) : null),
    };

    if (data.tabela === "recall") {
      chamadoRow.glpi = nullIfEmpty(c.GLPI || c.glpi);
    }

    // Regra: número do chamado não pode duplicar
    if (chamadoRow.chamado) {
      const { data: dup } = await supabase
        .from(tblMain).select("id").eq("chamado", chamadoRow.chamado).limit(1).maybeSingle();
      if (dup) throw new Error(`Já existe um chamado com o número ${chamadoRow.chamado}.`);
    }

    let { data: inserted, error: e1 } = await supabase
      .from(tblMain)
      .insert(chamadoRow)
      .select()
      .single();
    if (e1 && (e1.message?.includes("glpi") || e1.message?.includes("parceiro") || e1.code === "PGRST204")) {
      const rowCleaned = { ...chamadoRow };
      if (e1.message?.includes("glpi")) delete rowCleaned.glpi;
      if (e1.message?.includes("parceiro") || e1.code === "PGRST204") delete rowCleaned.parceiro;
      const res = await supabase.from(tblMain).insert(rowCleaned).select().single();
      inserted = res.data;
      e1 = res.error;
    }
    if (e1) {
      const msg = e1.message.includes("does not exist")
        ? `A tabela '${tblMain}' não existe no Supabase. Por favor, rode o script SQL '20260825133500_create_chamados_recall.sql' no Supabase.`
        : e1.message;
      throw new Error(msg);
    }
    const chamado_id = inserted.id;
    await upsertConferenteCD(supabase, chamadoRow.conferente, chamadoRow.cd);
    await upsertTransportadora(supabase, chamadoRow.transportadora);

    // Referências
    const refs = (data.referencias || [])
      .map((r: any) => ({
        chamado_id,
        referencia: nullIfEmpty(r.referencia),
        cor: nullIfEmpty(r.cor),
        tamanho: nullIfEmpty(r.tamanho),
        fornecedor: nullIfEmpty(r.fornecedor),
        descricao: nullIfEmpty(r.descricao),
        quantidade: numOrNull(r.quantidade),
      } as any))
      .filter((r: any) => r.referencia || r.cor || r.tamanho || r.fornecedor || r.descricao);
    if (refs.length > 0) {
      const { error: e2 } = await supabase.from(tblRefs).insert(refs);
      if (e2) throw new Error("Erro nas referências: " + e2.message);
    }

    // Etapas (calcula sla_status / dias_uteis_real quando dt_fim preenchida)
    const etapas = (data.etapas || []).map((et, idx) => {
      const inicio = parseISO(et.dt_inicio ?? null);
      const fim = parseISO(et.dt_fim ?? null);
      let dias_real: number | null = null;
      let sla: string | null = null;
      if (inicio && fim) {
        dias_real = diasUteisEntre(inicio, fim);
        if (et.dias_uteis_previsto != null) {
          sla = dias_real <= et.dias_uteis_previsto ? "Dentro do SLA" : "Fora do SLA";
        }
      } else if (inicio && !fim) {
        sla = "Em Aberto";
      }
      return {
        chamado_id,
        tarefa_id: et.tarefa_id || null,
        nome_tarefa: et.nome_tarefa,
        dias_uteis_previsto: et.dias_uteis_previsto ?? null,
        dt_inicio: dateOrNull(et.dt_inicio),
        dt_fim: dateOrNull(et.dt_fim),
        dias_uteis_real: dias_real,
        sla_status: sla,
        ordem: et.ordem ?? idx + 1,
      };
    });

    // Se não veio nenhuma etapa, cria "Aguardando Monitoramento" default
    if (etapas.length === 0) {
      const { data: t } = await supabase
        .from("tarefas_catalogo")
        .select("*")
        .ilike("nome", "%aguardando monitoramento%")
        .limit(1)
        .maybeSingle();
      const hoje = new Date().toISOString().slice(0, 10);
      etapas.push({
        chamado_id,
        tarefa_id: t?.id ?? null,
        nome_tarefa: t?.nome ?? "Aguardando Monitoramento",
        dias_uteis_previsto: t?.dias_uteis ?? 2,
        dt_inicio: hoje,
        dt_fim: null,
        dias_uteis_real: null,
        sla_status: "Em Aberto",
        ordem: 1,
      });
    }

    if (etapas.length > 0) {
      const { error: e3 } = await supabase.from(tblEtapas).insert(etapas);
      if (e3) throw new Error("Erro nas etapas: " + e3.message);
    }

    // Sync com planilha (fire-and-forget, apenas faltas por enquanto)
    if (data.tabela !== "recall") {
      try {
        const { syncToAppsScript, buildChamadoRow } = await import("@/lib/apps-script.server");
        await syncToAppsScript({
          action: "insert",
          chamado: buildChamadoRow(chamadoRow),
          referencias: refs,
          etapas,
        });
      } catch (e) { console.error("[sync] insert:", e); }
    }

    return { ok: true, id: chamado_id };
  });

// ===== Ler chamado completo =====
export const getChamadoCompleto = createServerFn({ method: "GET" })
  .validator((data: { id: string; tabela?: "faltas" | "recall" }) => data)
  .handler(async ({ data }) => {
    if (!data?.id) return { chamado: null, referencias: [], etapas: [] };
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();

    const tblMain = data.tabela === "recall" ? "chamados_recall" : "chamados_faltas";
    const tblRefs = data.tabela === "recall" ? "chamados_recall_referencias" : "chamados_referencias";
    const tblEtapas = data.tabela === "recall" ? "chamados_recall_etapas" : "chamados_etapas";

    let chamado: any = null;
    let refs: any[] = [];
    let etapas: any[] = [];

    // 1. Chamado principal
    try {
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(data.id);
      let query = supabase.from(tblMain).select("*");
      if (isUuid) {
        query = query.eq("id", data.id);
      } else {
        query = query.eq("chamado", data.id);
      }
      const { data: res, error: e1 } = await query.limit(1).maybeSingle();
      if (e1) throw new Error(e1.message);
      chamado = res;
    } catch {
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(data.id);
      const whereClause = isUuid ? `id = '${data.id}'` : `chamado = '${data.id}'`;
      const { data: rpcRes } = await supabase.rpc("aiiliana_run_sql", {
        sql: `SELECT * FROM ${tblMain} WHERE ${whereClause} LIMIT 1`
      });
      if (Array.isArray(rpcRes) && rpcRes.length > 0) chamado = rpcRes[0];
    }

    if (!chamado) return { chamado: null, referencias: [], etapas: [] };
    chamado.parceiro = chamado.parceiro || getParceiroByLoja(chamado.loja) || null;

    const cId = chamado.id;

    // 2. Referencias
    try {
      const { data: res, error: e2 } = await supabase.from(tblRefs).select("*").eq("chamado_id", cId);
      if (e2) throw new Error(e2.message);
      refs = res || [];
    } catch {
      const { data: rpcRes } = await supabase.rpc("aiiliana_run_sql", {
        sql: `SELECT * FROM ${tblRefs} WHERE chamado_id = '${cId}'`
      });
      if (Array.isArray(rpcRes)) refs = rpcRes;
    }

    // 3. Etapas
    try {
      const { data: res, error: e3 } = await supabase.from(tblEtapas).select("*").eq("chamado_id", cId).order("ordem");
      if (e3) throw new Error(e3.message);
      etapas = res || [];
    } catch {
      const { data: rpcRes } = await supabase.rpc("aiiliana_run_sql", {
        sql: `SELECT * FROM ${tblEtapas} WHERE chamado_id = '${cId}' ORDER BY ordem ASC`
      });
      if (Array.isArray(rpcRes)) etapas = rpcRes;
    }

    return { chamado, referencias: refs, etapas };
  });

// ===== Atualizar chamado completo (substitui refs e etapas) =====
export const updateChamadoCompleto = createServerFn({ method: "POST" })
  .validator((data: {
    id: string;
    chamado: any;
    referencias: any[];
    etapas: EtapaInput[];
    tabela?: "faltas" | "recall";
  }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();

    const tblMain = data.tabela === "recall" ? "chamados_recall" : "chamados_faltas";
    const tblRefs = data.tabela === "recall" ? "chamados_recall_referencias" : "chamados_referencias";
    const tblEtapas = data.tabela === "recall" ? "chamados_recall_etapas" : "chamados_etapas";

    const c = data.chamado;
    const nullIfEmpty = (v: any) => {
      if (v === undefined || v === null) return null;
      const s = String(v).trim();
      return s === "" ? null : s;
    };
    const numOrNull = (v: any) => {
      const s = nullIfEmpty(v);
      if (!s) return null;
      const n = Number(String(s).replace(",", "."));
      return isNaN(n) ? null : n;
    };
    const dateOrNull = (v: any) => {
      const s = nullIfEmpty(v);
      if (!s) return null;
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
      if (m) return `${m[1]}-${m[2]}-${m[3]}`;
      const d = new Date(s);
      if (isNaN(d.getTime())) return null;
      return d.toISOString().slice(0, 10);
    };

    const row: any = {
      chamado: nullIfEmpty(c.Chamado),
      loja: nullIfEmpty(c.Loja),
      tipo: nullIfEmpty(c.Tipo),
      nf: nullIfEmpty(c.NF),
      dt_emissao: dateOrNull(c["Dt Emissão"]),
      valor: numOrNull(c[" Valor "]),
      cd: nullIfEmpty(c.CD),
      situacao: nullIfEmpty(c["Situação "]),
      dt_abertura: dateOrNull(c["Dt Abertura"]),
      dt_finalizacao: dateOrNull(c["Dt Finalização"]),
      dt_pagamento: dateOrNull(c["Dt Pagamento"]),
      sla_status: nullIfEmpty(c["SLA por chamado (60dias)"]),
      status_pagamento: nullIfEmpty(c["Status Pagamento"]),
      status_chamado: nullIfEmpty(c["Status Chamado"]),
      motivo: nullIfEmpty(c.Motivo),
      transportadora: nullIfEmpty(c.Transportadora),
      conferente: nullIfEmpty(c.Conferente),
      periodo: dateOrNull(c.Periodo),
      parceiro: nullIfEmpty(c.Parceiro || c.parceiro) || (c.Loja ? getParceiroByLoja(c.Loja) : null),
    };

    if (data.tabela === "recall") {
      row.glpi = nullIfEmpty(c.GLPI || c.glpi);
    }

    // Regra: número do chamado não pode duplicar (exceto o próprio)
    if (row.chamado) {
      const { data: dup } = await supabase
        .from(tblMain).select("id").eq("chamado", row.chamado).neq("id", data.id).limit(1).maybeSingle();
      if (dup) throw new Error(`Já existe outro chamado com o número ${row.chamado}.`);
    }
    let { error: eu } = await supabase.from(tblMain).update(row).eq("id", data.id);
    if (eu && (eu.message?.includes("glpi") || eu.message?.includes("parceiro") || eu.code === "PGRST204")) {
      const rowCleaned = { ...row };
      if (eu.message?.includes("glpi")) delete rowCleaned.glpi;
      if (eu.message?.includes("parceiro") || eu.code === "PGRST204") delete rowCleaned.parceiro;
      const res = await supabase.from(tblMain).update(rowCleaned).eq("id", data.id);
      eu = res.error;
    }
    if (eu) throw new Error(eu.message);
    await upsertConferenteCD(supabase, row.conferente, row.cd);
    await upsertTransportadora(supabase, row.transportadora);

    // refs: delete + reinsert
    await supabase.from(tblRefs).delete().eq("chamado_id", data.id);
    const refs = (data.referencias || [])
      .map((r: any) => ({
        chamado_id: data.id,
        referencia: nullIfEmpty(r.referencia),
        cor: nullIfEmpty(r.cor),
        tamanho: nullIfEmpty(r.tamanho),
        fornecedor: nullIfEmpty(r.fornecedor),
        descricao: nullIfEmpty(r.descricao),
        quantidade: numOrNull(r.quantidade),
      } as any))
      .filter((r: any) => r.referencia || r.cor || r.tamanho || r.fornecedor || r.descricao);
    if (refs.length > 0) {
      const { error } = await (supabase.from(tblRefs) as any).insert(refs);
      if (error) throw new Error("Erro nas referências: " + error.message);
    }

    // etapas: delete + reinsert
    await supabase.from(tblEtapas).delete().eq("chamado_id", data.id);
    const etapas = (data.etapas || []).map((et, idx) => {
      const inicio = parseISO(et.dt_inicio ?? null);
      const fim = parseISO(et.dt_fim ?? null);
      let dias_real: number | null = null;
      let sla: string | null = null;
      if (inicio && fim) {
        dias_real = diasUteisEntre(inicio, fim);
        if (et.dias_uteis_previsto != null) {
          sla = dias_real <= et.dias_uteis_previsto ? "Dentro do SLA" : "Fora do SLA";
        }
      } else if (inicio && !fim) {
        sla = "Em Aberto";
      }
      return {
        chamado_id: data.id,
        tarefa_id: et.tarefa_id || null,
        nome_tarefa: et.nome_tarefa,
        dias_uteis_previsto: et.dias_uteis_previsto ?? null,
        dt_inicio: et.dt_inicio || null,
        dt_fim: et.dt_fim || null,
        dias_uteis_real: dias_real,
        sla_status: sla,
        ordem: et.ordem ?? idx + 1,
      };
    }).filter((e) => e.nome_tarefa);
    if (etapas.length > 0) {
      const { error } = await supabase.from(tblEtapas).insert(etapas);
      if (error) throw new Error("Erro nas etapas: " + error.message);
    }
    // Sync com planilha (fire-and-forget, apenas faltas por enquanto)
    if (data.tabela !== "recall") {
      try {
        const { syncToAppsScript, buildChamadoRow } = await import("@/lib/apps-script.server");
        await syncToAppsScript({
          action: "update",
          chamado: buildChamadoRow(row),
          referencias: refs,
          etapas,
        });
      } catch (e) { console.error("[sync] update:", e); }
    }

    return { ok: true, id: data.id };
  });

// ===== Excluir chamado(s) =====
export const deleteChamado = createServerFn({ method: "POST" })
  .validator((data: { ids: string[]; tabela?: "faltas" | "recall" }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();

    const tblMain = data.tabela === "recall" ? "chamados_recall" : "chamados_faltas";
    const tblRefs = data.tabela === "recall" ? "chamados_recall_referencias" : "chamados_referencias";
    const tblEtapas = data.tabela === "recall" ? "chamados_recall_etapas" : "chamados_etapas";

    const ids = (data.ids || []).filter(Boolean);
    if (!ids.length) return { ok: true, count: 0 };

    // Pega os números dos chamados antes de deletar (para sincronizar com a planilha)
    const { data: chamadosRows } = await supabase
      .from(tblMain).select("chamado").in("id", ids);
    const chamadoNums = (chamadosRows || []).map((r: any) => String(r.chamado)).filter(Boolean);

    await supabase.from(tblEtapas).delete().in("chamado_id", ids);
    await supabase.from(tblRefs).delete().in("chamado_id", ids);
    const { error } = await supabase.from(tblMain).delete().in("id", ids);
    if (error) throw new Error(error.message);

    // Sync com planilha (apenas se for faltas)
    if (data.tabela !== "recall") {
      try {
        const { syncToAppsScript } = await import("@/lib/apps-script.server");
        await syncToAppsScript({ action: "delete", ids: chamadoNums });
      } catch (e) { console.error("[sync] delete:", e); }
    }

    return { ok: true, count: ids.length };
  });

// ===== Alterar tarefas em lote =====
export const updateMultipleChamadosTarefas = createServerFn({ method: "POST" })
  .validator((data: { ids: string[]; novaTarefa: string; tabela?: "faltas" | "recall" }) => data)
  .handler(async ({ data }) => {
    const { requireUnlockedSession } = await import("@/lib/gate.server");
    await requireUnlockedSession();
    const supabase = await getSupabase();

    const ids = (data.ids || []).filter(Boolean);
    if (!ids.length) return { ok: true, count: 0 };
    const novaTarefa = String(data.novaTarefa || "").trim();
    if (!novaTarefa) throw new Error("A nova tarefa não pode ser vazia.");

    const tblMain = data.tabela === "recall" ? "chamados_recall" : "chamados_faltas";
    const tblEtapas = data.tabela === "recall" ? "chamados_recall_etapas" : "chamados_etapas";

    // 1. Busca informação da tarefa no catálogo
    const { data: catRows } = await supabase
      .from("tarefas_catalogo")
      .select("id, nome, dias_uteis")
      .ilike("nome", novaTarefa)
      .limit(1);
    const catTarefa = catRows?.[0];

    const todayStr = new Date().toISOString().slice(0, 10);
    const isFinalizadoOuRecusado = /finaliz/i.test(novaTarefa) || /recusad/i.test(novaTarefa);

    // 2. Atualiza situacao na tabela principal
    const updatePayload: any = {
      situacao: novaTarefa,
      updated_at: new Date().toISOString(),
    };
    if (isFinalizadoOuRecusado) {
      updatePayload.dt_finalizacao = todayStr;
    }

    const { error: errUpdate } = await supabase
      .from(tblMain)
      .update(updatePayload)
      .in("id", ids);

    if (errUpdate) {
      throw new Error("Erro ao atualizar situação dos chamados: " + errUpdate.message);
    }

    // 3. Atualizar etapas para cada chamado
    for (const chId of ids) {
      try {
        // Encerra etapas abertas
        const { data: openEtapas } = await supabase
          .from(tblEtapas)
          .select("id, dt_inicio, dias_uteis_previsto")
          .eq("chamado_id", chId)
          .is("dt_fim", null);

        if (openEtapas && openEtapas.length > 0) {
          for (const oe of openEtapas) {
            let diasReal = 0;
            let sla = "Dentro do SLA";
            if (oe.dt_inicio) {
              const dIni = parseISO(oe.dt_inicio);
              const dFim = parseISO(todayStr);
              if (dIni && dFim) {
                diasReal = diasUteisEntre(dIni, dFim);
                if (oe.dias_uteis_previsto != null) {
                  sla = diasReal <= oe.dias_uteis_previsto ? "Dentro do SLA" : "Fora do SLA";
                }
              }
            }
            await supabase
              .from(tblEtapas)
              .update({
                dt_fim: todayStr,
                dias_uteis_real: diasReal,
                sla_status: sla,
                updated_at: new Date().toISOString(),
              })
              .eq("id", oe.id);
          }
        }

        // Determina a próxima ordem
        const { data: maxOrdemData } = await supabase
          .from(tblEtapas)
          .select("ordem")
          .eq("chamado_id", chId)
          .order("ordem", { ascending: false })
          .limit(1);

        const nextOrdem = (maxOrdemData?.[0]?.ordem ?? 0) + 1;

        await supabase
          .from(tblEtapas)
          .insert({
            chamado_id: chId,
            tarefa_id: catTarefa?.id || null,
            nome_tarefa: novaTarefa,
            dias_uteis_previsto: catTarefa?.dias_uteis ?? 2,
            dt_inicio: todayStr,
            dt_fim: isFinalizadoOuRecusado ? todayStr : null,
            dias_uteis_real: isFinalizadoOuRecusado ? 0 : null,
            sla_status: isFinalizadoOuRecusado ? "Dentro do SLA" : "Em Aberto",
            ordem: nextOrdem,
          });
      } catch (err) {
        console.warn(`[updateMultipleChamadosTarefas] Erro nas etapas do chamado ${chId}:`, err);
      }
    }

    return { ok: true, count: ids.length, novaTarefa };
  });

